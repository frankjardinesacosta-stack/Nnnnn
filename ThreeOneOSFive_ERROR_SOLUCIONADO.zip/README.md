# ThreeOneOSFive - IPA Modificado

## Contenido
- `ThreeOneOSFive_modified.ipa` → IPA con el texto "Pacote" eliminado
- `UI_editado.jpg` → Imagen de referencia con los cambios visuales:
  - Logo de Telegram más pequeño y en la posición de "Cerrar sesión"
  - Sin botón "Cerrar sesión"
  - Sin textos "Pacote"
  - Nombres: AIM PECHO+CUELO / AIM HEAD / AIM CUELLO / AIM PECHO

## Cómo usar en GitHub
1. Sube **todo** el contenido de este ZIP a la raíz de tu repositorio.
2. El workflow `.github/workflows/build-ipa.yml` ya está listo y **no intenta compilar** (porque no hay `.xcodeproj`).
3. Al hacer push, el Action solo validará el IPA y lo subirá como artifact.

## Nota sobre el error anterior
El error `ThreeOneOSFive.xcodeproj does not exist` ocurría porque se intentaba usar `xcodebuild` sobre un proyecto que no existe.  
Este workflow lo soluciona: solo empaqueta y valida el IPA ya compilado.
